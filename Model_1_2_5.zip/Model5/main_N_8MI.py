import gc
import sys
import time
import onnx
import pickle
import joblib
import warnings
import numpy as np
import tracemalloc
import pandas as pd
import onnxruntime as ort
warnings.filterwarnings("ignore")
from sklearn.metrics import confusion_matrix

if __name__ == '__main__':

    print('---------------TESTING the QRF model---------------')

    # === Step 1: Load and preprocess test data ===
    Test_Features = pd.read_csv("TEST_N_8MI.csv", sep='\t')
    mapping_dict = {1: 1, 21: 2, 22: 3, 23: 4, 24: 5, 25: 6, 26: 7, 28: 8, 31: 9}
    Test_Features['CLS'] = Test_Features['CLS'].map(mapping_dict)

    # Define all feature names
    feature_name = ["Rht", "Qht", "Sht", "QRSd", "RARE", "QRang", "SRang", "QRSang", "QRd", "SRd",
                    "Tht", "TARE", "Td", "(Toff-Qon)/1000", "Tonang", "Toffang", "Tang", "TTond",
                    "TToffd", "TW_polarity", "mean(abs(ECG))", "std(abs(ECG))", "ST_seg", "PWFD",
                    "MxF", "MxFPSD", "TotPSD", "MedF_PSD", "MedF_FFT", "TotEntropy", "kurtosis",
                    "skewness", "variance", "Ton_SLP", "Toff_SLP", "MOM5", "MOM6", "E10", "E30",
                    "E100", "HFD", "Lead", "CLS"]

    Test_Features.columns = feature_name

    # === Step 3: Normalize features ===
    cols_to_norm = feature_name[:-2]  # Exclude "Lead" and "CLS"
    scaler = joblib.load("Std_scaler_9cls.save")
    Test_Features[cols_to_norm] = scaler.transform(Test_Features[cols_to_norm])

    # === Step 4: Prepare test data ===
    X_test = Test_Features.iloc[:, 0:-1]  # All except CLS
    Y_test = Test_Features.iloc[:, -1]  # CLS

    # === Step 5: Load best features list from model metadata ===
    result = pickle.load(open("TRF.sav", "rb"))
    best_features = result["features"]
    best_feature_names = [feature_name[i] for i in best_features]

    # Select only best features
    X_test = X_test[best_feature_names]

    # === Step 6: Inference using quantized ONNX model ===
    # Load ONNX Runtime session
    session = ort.InferenceSession("QRF.onnx")

    # ONNX expects input to be float32
    X_test_onnx = X_test.to_numpy().astype(np.float32)

    # Prepare input dictionary
    input_name = session.get_inputs()[0].name
    start_time = time.time()
    outputs = session.run(None, {input_name: X_test_onnx})
    end_time = time.time()
    runtime = end_time - start_time
    Y_pred = np.array(outputs[0]).flatten()
    print('Time / prediction = ', runtime / len(Y_pred))

    # === Step 7: Evaluate performance ===
    conf_mat = confusion_matrix(Y_test, Y_pred)
    print("Confusion Matrix:")
    print(conf_mat)

    # ===================================================================================================================
    # Knowledge distillation
    # ===================================================================================================================

    # Test data
    Test_Features = pd.read_csv("TEST_N_8MI.csv", sep='\t')
    Test_Features['CLS'] = Test_Features['CLS'].map({1: 1, 21: 2, 22: 3, 23: 4, 24: 5, 25: 6, 26: 7, 28: 8, 31: 9})
    Test_Features.columns = ["Rht", "Qht", "Sht", "QRSd", "RARE", "QRang", "SRang", "QRSang", "QRd", "SRd",
                             "Tht", "TARE", "Td", "(Toff-Qon)/1000", "Tonang", "Toffang", "Tang", "TTond",
                             "TToffd", "TW_polarity", "mean(abs(ECG))", "std(abs(ECG))", "ST_seg", "PWFD",
                             "MxF", "MxFPSD", "TotPSD", "MedF_PSD", "MedF_FFT", "TotEntropy", "kurtosis",
                             "skewness", "variance", "Ton_SLP", "Toff_SLP", "MOM5", "MOM6", "E10", "E30",
                             "E100", "HFD", "Lead", "CLS"]

    # Apply same scaler
    scaler = joblib.load("Std_scaler_9cls.save")
    cols_to_norm = ["Rht", "Qht", "Sht", "QRSd", "RARE", "QRang", "SRang", "QRSang", "QRd", "SRd",
                    "Tht", "TARE", "Td", "(Toff-Qon)/1000", "Tonang", "Toffang", "Tang", "TTond",
                    "TToffd", "TW_polarity", "mean(abs(ECG))", "std(abs(ECG))", "ST_seg", "PWFD",
                    "MxF", "MxFPSD", "TotPSD", "MedF_PSD", "MedF_FFT", "TotEntropy", "kurtosis",
                    "skewness", "variance", "Ton_SLP", "Toff_SLP", "MOM5", "MOM6", "E10", "E30",
                    "E100", "HFD"]
    Test_Features[cols_to_norm] = scaler.transform(Test_Features[cols_to_norm])
    Test_Features = Test_Features.astype({"Lead": 'int', "CLS": 'int'})

    X_test = Test_Features.iloc[:, 0:-1].to_numpy()
    Y_test = Test_Features.iloc[:, -1].tolist()
    X_distill = X_test[:, best_features]

    print('\n\n---------------TESTING the KDS model---------------')
    with open("KDS.pkl", "rb") as f:
        final_model = pickle.load(f)
    gc.collect()
    #tracemalloc.start()
    start_time = time.time()
    Y_pred_final = final_model.predict(X_distill)
    end_time = time.time()
    runtime = end_time - start_time
    print('Time / prediction = ', runtime / len(Y_pred))
    #current, peak = tracemalloc.get_traced_memory()
    #tracemalloc.stop()
    #print(f"Peak memory usage during prediction: {peak} bytes ({peak / 1024:.2f} KiB)")
    conf_mat = confusion_matrix(Y_test, Y_pred_final)
    print(conf_mat)
